"""Continuous decode batching with bounded admission and cancellable streams.

One worker owns the GPU. Requests join/free KV slots between decode steps.
Model groups drain before switching; a queued different model prevents new
admission to the current group, avoiding starvation and active-model eviction.
"""
from collections import deque
import copy
import math
import traceback
from dataclasses import dataclass, field
import queue
import threading
import time

from .runtime import Runtime, BusyError
from .sampling import Sampling, Sampler, sample_rows
from .stopping import stop_sequences, text_delta
from .prompts import decode_output
from .admission import wait_for_batch


@dataclass(eq=False)
class Pending:
    alias: str
    messages: list
    max_tokens: int
    enable_thinking: bool | None = None
    sampler: Sampler = field(default_factory=lambda: Sampler(Sampling()))
    stops: tuple = ()
    raw_prompt: str | list | None = None
    schema: str | None = None
    tools: list | None = None
    tool_json: bool = False
    command: dict | None = None
    start: float = field(default_factory=time.perf_counter)
    events: queue.Queue = field(default_factory=lambda: queue.Queue(maxsize=8))
    done: threading.Event = field(default_factory=threading.Event)
    ready: threading.Event = field(default_factory=threading.Event)
    cancelled: threading.Event = field(default_factory=threading.Event)
    error: Exception | None = None
    final: dict | None = None
    output: list = field(default_factory=list)
    emitted: str = ""
    first_time: float | None = None
    last_progress: float = field(default_factory=time.monotonic)
    max_batch_seen: int = 1
    slot: int = -1
    tier: str = "gpu"
    activation: float = 0
    cached_tokens: int = 0
    speculative_prompt: tuple = ()
    speculative_blocks: int = 0
    speculative_proposed: int = 0
    speculative_matched: int = 0
    speculative_misses: int = 0
    speculative_cooldown: int = 0
    reasoning_effort: str | None = None
    output_decoder: object | None = None


class BatchedRuntime:
    def __init__(self, models, batch_size=4, queue_size=8, queue_timeout=120, prefill_chunk_size=0, prefix_cache_tokens=0, batch_wait_ms=0, **kwargs):
        if not 1 <= batch_size <= 16 or queue_size < batch_size or queue_timeout <= 0:
            raise ValueError("batch size must be 1..16 and fit inside the request queue")
        if type(prefill_chunk_size) is not int or prefill_chunk_size<0:
            raise ValueError('prefill chunk size must be a nonnegative integer')
        if type(prefix_cache_tokens) is not int or prefix_cache_tokens<0:
            raise ValueError('prefix cache tokens must be a nonnegative integer')
        if type(batch_wait_ms) not in (int,float) or not math.isfinite(batch_wait_ms) or not 0<=batch_wait_ms<=10:
            raise ValueError("batch wait must be a finite number between 0 and 10 milliseconds")
        self.batch_wait_seconds=batch_wait_ms/1000
        self.prefix_cache_tokens=prefix_cache_tokens
        self.prefill_chunk_size=prefill_chunk_size
        from .partition_policy import selected_split
        if selected_split() is not None and (prefill_chunk_size or prefix_cache_tokens):
            raise ValueError('layer partition does not yet support chunked prefill or prefix snapshots')
        self.runtime = Runtime(models, batch_size=batch_size, **kwargs)
        if prefill_chunk_size or prefix_cache_tokens:
            from .device import selected_device
            if selected_device()=='cuda':
                # Load offset-attention dispatch before the server advertises
                # readiness, not on the first partial-prefix hit.
                from torch.nn.attention.bias import causal_lower_right
        self.models = self.runtime.models
        self.batch_size = batch_size
        self.queue_timeout = queue_timeout
        self.admission = threading.BoundedSemaphore(queue_size)
        self.condition = threading.Condition()
        self.pending = deque()
        self.requests = set()
        self.closed = False
        self.worker = threading.Thread(target=self._work, name="dllm-gpu", daemon=True)
        self.worker.start()

    def model_ids(self):
        return self.runtime.model_ids()

    def manage(self, action, model=None, path=None, release_host=False, quantization=None, chat_template=None):
        from .management import command
        return self._submit(command(action, model, path, release_host, quantization, chat_template))

    def embed(self, alias, inputs, encoding_format="float", dimensions=None):
        from .embeddings import options
        inputs, encoding_format, dimensions = options(inputs, encoding_format, dimensions)
        if not isinstance(alias, str) or alias not in self.models:
            raise ValueError("unknown model")
        return self._submit({"action":"embed", "model":alias, "inputs":inputs,
                             "encoding_format":encoding_format, "dimensions":dimensions})

    def rerank(self,alias,query,documents,top_n=None,return_documents=False):
        from .reranking import options
        query,documents,top_n,return_documents=options(query,documents,top_n,return_documents)
        if not isinstance(alias,str) or alias not in self.models:raise ValueError('unknown model')
        return self._submit({'action':'rerank','model':alias,'query':query,'documents':documents,
            'top_n':top_n,'return_documents':return_documents})

    def score(self,alias,prompt,candidate_token_ids):
        from .scoring import options
        prompt,candidates=options(prompt,candidate_token_ids)
        if not isinstance(alias,str) or alias not in self.models:raise ValueError('unknown model')
        return self._submit({'action':'score','model':alias,'prompt':prompt,'candidate_token_ids':candidates})

    def _submit(self, options):
        if not self.admission.acquire(blocking=False):
            raise BusyError('request queue is full')
        request = Pending(options.get('model') or '', None, 0, command=options)
        try:
            with self.condition:
                if self.closed:
                    raise BusyError('runtime is closed')
                self.requests.add(request)
                self.pending.append(request)
                self.condition.notify_all()
            request.done.wait()
            if request.error:
                raise request.error
            return request.final
        finally:
            request.cancelled.set()
            with self.condition:
                try:
                    self.pending.remove(request)
                except ValueError:
                    pass
                self.requests.discard(request)
                self.condition.notify_all()
            self.admission.release()

    def generate(self, alias, messages, max_tokens=128, enable_thinking=None,
                 temperature=0, top_p=1, top_k=0, seed=None, stop=None, raw_prompt=None, response_format=None,
                 presence_penalty=0, frequency_penalty=0, repetition_penalty=1, logit_bias=None,
                 logprobs=False,top_logprobs=0,tools=None,tool_choice=None,reasoning_effort=None):
        if alias not in self.models:
            raise ValueError("unknown model")
        if type(max_tokens) is not int or max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        sampler = Sampler(Sampling(temperature, top_p, top_k, seed, presence_penalty, frequency_penalty, repetition_penalty, logit_bias))
        stops = stop_sequences(stop)
        from .tool_calls import prepare_tools
        tools,tool_schema=prepare_tools(tools,tool_choice)
        if tools and (raw_prompt is not None or response_format is not None or logprobs or stops):
            raise ValueError('tool calls cannot combine with raw prompts, structured output, scores or custom stops')
        from .logprobs import options as score_options
        sampler.logprobs_top=score_options(logprobs,top_logprobs)
        if stops and sampler.logprobs_top is not None:
            raise ValueError('logprobs with custom text stops is not yet supported')
        if raw_prompt is not None:
            from .prompts import validate_raw
            raw_prompt = validate_raw(raw_prompt)
            if messages is not None or enable_thinking is not None or reasoning_effort is not None:
                raise ValueError('raw prompts cannot include chat messages or template options')
        from .structured import prepare_options
        schema, enable_thinking = prepare_options(response_format, stops, enable_thinking)
        if tool_schema is not None:
            if enable_thinking is True:
                raise ValueError('forced tool calls cannot use thinking or ignore_eos')
            schema=tool_schema
        if not self.admission.acquire(blocking=False):
            raise BusyError("request queue is full")
        request = Pending(alias, copy.deepcopy(messages), max_tokens, enable_thinking, sampler, stops, raw_prompt, schema,tools=tools,tool_json=tool_schema is not None,reasoning_effort=reasoning_effort)
        try:
            with self.condition:
                if self.closed:
                    raise BusyError("runtime is closed")
                self.requests.add(request)
                self.pending.append(request)
                self.condition.notify_all()
            while True:
                request.ready.clear()
                try:
                    event = request.events.get_nowait()
                except queue.Empty:
                    if request.done.is_set():
                        # A producer can enqueue its last block and finish
                        # between get_nowait() observing empty and this check.
                        if not request.events.empty():continue
                        if request.error:
                            raise request.error
                        if request.final:
                            yield request.final
                        return
                    request.ready.wait()
                    continue
                with self.condition:
                    self.condition.notify_all()
                yield event
        finally:
            request.cancelled.set()
            with self.condition:
                try:
                    self.pending.remove(request)
                except ValueError:
                    pass
                self.requests.discard(request)
                self.condition.notify_all()
            self.admission.release()

    def _finish(self, request, error=None):
        with self.condition:
            if request.done.is_set():
                return
            if error is not None:
                # Do not transport worker frames (and their GPU tensors) to the
                # caller. A retained exception must not pin an evicted model.
                try:
                    detached = copy.copy(error).with_traceback(None)
                except Exception:
                    detached = RuntimeError(str(error))
                detached.__cause__ = detached.__context__ = None
                detached.__notes__ = list(getattr(error, '__notes__', ()))
                if error.__traceback__ is not None:
                    detached.add_note('Worker traceback:\n'+''.join(traceback.format_tb(error.__traceback__)))
                error = detached
            request.error = error
            request.done.set()
            request.ready.set()
            self.requests.discard(request)

    def _emit(self, request, token, executor, prompt_count):
        if request.cancelled.is_set():
            self._finish(request)
            return True
        if request.sampler.constraint is not None:
            request.sampler.constraint.accept(token)
        request.sampler.observe(token)
        request.output.append(token)
        now = time.perf_counter()
        if request.first_time is None:
            request.first_time = now - request.start
        request.last_progress = time.monotonic()
        stop = token in executor.model.eos
        finished = stop or len(request.output) >= request.max_tokens
        reasoning=''
        if request.output_decoder is not None:
            delta,reasoning,text_stop=request.output_decoder.feed(token,final=finished)
        else:
            decoded = decode_output(executor.model, request.output)
            delta, request.emitted, text_stop = text_delta(decoded, request.emitted, request.stops, finished)
        stop = stop or text_stop
        finished = finished or text_stop
        event={"token": token, "text": delta}
        if request.output_decoder is not None:
            event['tool_call_format']='harmony'
            if request.output_decoder.calls:event['tool_calls']=request.output_decoder.calls
        if reasoning:event['reasoning_content']=reasoning
        if request.sampler.logprobs_top is not None and token not in executor.model.eos:
            event['logprobs']=request.sampler.token_decoder.format(request.sampler.last_logprobs)
        request.events.put_nowait(event)
        request.ready.set()
        if finished:
            elapsed = time.perf_counter() - request.start
            count = len(request.output)
            reason="tool_calls" if request.output_decoder is not None and request.output_decoder.calls else "stop" if stop else "length"
            request.final = {"finish_reason": reason, "usage": {
                "prompt_tokens": prompt_count, "completion_tokens": count,
                "total_tokens": prompt_count + count}, "timing": {
                "source_tier": request.tier, "activation_seconds": request.activation,
                "cached_prompt_tokens":request.cached_tokens,
                "speculative_blocks":request.speculative_blocks,
                "speculative_proposed_drafts":request.speculative_proposed,
                "speculative_matched_drafts":request.speculative_matched,
                "kernel_backend": executor.kernel_backend,
                "weight_quantization": getattr(executor.model, "weight_format", getattr(executor.model, "quantization", "none")), "max_batch_size": request.max_batch_seen,
                "residual_dtype": str(executor.residual_dtype).removeprefix("torch."),
                "first_token_seconds": request.first_time, "total_seconds": elapsed,
                "decode_tokens_per_second": (count-1)/(elapsed-request.first_time)
                if count > 1 and elapsed > request.first_time else None}}
            self._finish(request)
        return finished

    def _next(self, alias=None):
        """Caller holds the condition. Preserve FIFO across model groups."""
        while self.pending:
            first = self.pending[0]
            if first.cancelled.is_set():
                self.pending.popleft()
                self._finish(first)
            elif time.perf_counter() - first.start > self.queue_timeout:
                self.pending.popleft()
                self._finish(first, BusyError("request queue timeout"))
            elif alias is not None and (first.command is not None or first.alias != alias):
                return None
            else:
                return self.pending.popleft()
        return None

    def _prepare(self,request,executor):
        from .prompts import encode,validate_lengths,decoder_prefix
        thinking=request.enable_thinking
        if request.schema is not None and request.raw_prompt is None and executor.model.config['model_type'] in ('qwen3','qwen3_5_text'):
            thinking=False
        tokens=encode(executor.model,request.messages,request.raw_prompt,thinking,request.tools,request.tool_json,request.reasoning_effort)
        validate_lengths(executor,len(tokens),request.max_tokens)
        from .harmony import output_stream
        request.output_decoder=output_stream(executor.model,request.raw_prompt,request.stops,
            request.schema,request.sampler.logprobs_top,tools=request.tools)
        if request.schema is not None:
            from .structured import Constraint
            request.sampler.constraint=Constraint(executor.model,request.schema)
        if request.sampler.has_adjustments:
            request.sampler.prepare(decoder_prefix(executor,tokens),executor.model.config['vocab_size'])
        if request.sampler.logprobs_top is not None:
            from .logprobs import decoder_for
            request.sampler.token_decoder=decoder_for(executor.model)
        if getattr(executor,'speculative_verifier',None) is not None:
            from .speculative import eligible
            if eligible(request) and not self.prefill_chunk_size and not self.prefix_cache_tokens:
                request.speculative_prompt=tuple(tokens[-1024:])
                # Room for two verification blocks overlaps GPU work with the
                # consumer draining the previous block. Keep the same queue
                # object because the consumer may already be waiting on it.
                with request.events.mutex:
                    request.events.maxsize=max(8,2*executor.speculative_verifier.width)
        return tokens

    def _speculate(self,ready,active,executor):
        verifier=getattr(executor,'speculative_verifier',None)
        if verifier is None or len(active)!=1 or len(ready)!=1:return False
        slot,request,prompt_count=ready[0]
        if not request.speculative_prompt:return False
        if request.speculative_cooldown:
            request.speculative_cooldown-=1
            return False
        remaining=request.max_tokens-len(request.output)
        start=executor.lengths[slot]
        capacity=request.events.maxsize-request.events.qsize()
        limit=min(verifier.width-1,remaining-1,capacity-1)
        if limit<1 or start+verifier.width>executor.context:
            return False
        from .speculative import propose
        history=(list(request.speculative_prompt)+request.output[-1024:])[-1024:]
        drafts=propose(history,limit)
        if not drafts:return False
        tokens,matched=verifier.verify(request.output[-1],drafts,start,slot)
        request.speculative_blocks+=1;request.speculative_proposed+=len(drafts)
        request.speculative_matched+=matched
        request.speculative_misses=0 if matched else request.speculative_misses+1
        if request.speculative_misses>=2:
            request.speculative_cooldown=8;request.speculative_misses=0
        previous=len(request.output)
        try:
            for token in tokens:
                if self._emit(request,token,executor,prompt_count):
                    del active[slot]
                    break
        finally:
            # The last emitted token remains the next decode input. Rejected,
            # filler and post-EOS positions cannot extend the committed prefix.
            executor.lengths[slot]=start+len(request.output)-previous
        return True

    def _chunked_group(self,first,executor,tier,activation):
        first.tier,first.activation=tier,activation
        active,partial={},{}
        cache=getattr(executor,'prefix_cache',None)
        if self.prefix_cache_tokens and cache is None:
            from .prefix import PrefixCache
            cache=executor.prefix_cache=PrefixCache(executor,self.prefix_cache_tokens)
        chunk_size=self.prefill_chunk_size or executor.context
        next_request=first
        try:
            while next_request is not None or active or partial:
                if next_request is not None:
                    incoming=[next_request]
                    next_request=None
                    with self.condition:
                        while len(incoming)+len(active)+len(partial)<self.batch_size:
                            request=self._next(first.alias)
                            if request is None:break
                            incoming.append(request)
                    for request in incoming:
                        try:
                            if request.cancelled.is_set():
                                self._finish(request)
                                continue
                            tokens=self._prepare(request,executor)
                            request.slot=next(i for i in range(self.batch_size) if i not in active and i not in partial)
                            reused,logits=cache.restore(tokens,request.slot) if cache is not None else (0,None)
                            request.cached_tokens=reused
                            if logits is not None:
                                token=request.sampler.select(logits.squeeze(0)).item()
                                if not self._emit(request,token,executor,len(tokens)):
                                    active[request.slot]=(request,len(tokens))
                            else:
                                partial[request.slot]=(request,tokens,reused)
                        except Exception as error:
                            self._finish(request,error)
                for slot,(request,_,__) in list(partial.items()):
                    if request.cancelled.is_set():
                        self._finish(request)
                        del partial[slot]
                # At most one bounded prompt chunk before each decode step.
                if partial:
                    slot=next(iter(partial))
                    request,tokens,start=partial[slot]
                    end=min(start+chunk_size,len(tokens))
                    try:
                        logits=executor.prefill_chunk(tokens[start:end],slot,start,final=end==len(tokens))
                        if end==len(tokens):
                            if cache is not None:cache.remember(tokens,slot,logits)
                            token=request.sampler.select(logits.squeeze(0)).item()
                            if not self._emit(request,token,executor,len(tokens)):
                                active[slot]=(request,len(tokens))
                            del partial[slot]
                        else:
                            partial[slot]=(request,tokens,end)
                    except Exception as error:
                        self._finish(request,error)
                        del partial[slot]
                for slot,(request,_) in list(active.items()):
                    if request.cancelled.is_set():
                        self._finish(request)
                        del active[slot]
                    elif request.events.full() and time.monotonic()-request.last_progress>self.queue_timeout:
                        self._finish(request,BusyError('stream backpressure timeout'))
                        del active[slot]
                ready=[(slot,request,length) for slot,(request,length) in active.items() if not request.events.full()]
                if ready:
                    logits,next_tokens=executor.decode_batch([r.output[-1] for _,r,_ in ready],[slot for slot,_,_ in ready])
                    selected=sample_rows(logits,[r.sampler for _,r,_ in ready],next_tokens)
                    for (slot,request,length),token in zip(ready,selected):
                        request.max_batch_seen=max(request.max_batch_seen,len(ready))
                        if self._emit(request,token,executor,length):del active[slot]
                with self.condition:
                    if len(active)+len(partial)<self.batch_size:
                        next_request=self._next(first.alias)
                    if active and not ready and not partial and next_request is None:
                        self.condition.wait(timeout=.02)
        except Exception as error:
            for request,_ in active.values():self._finish(request,error)
            for request,_,__ in partial.values():self._finish(request,error)
            if next_request:self._finish(next_request,error)
            raise

    def _paged_group(self, first, executor, tier, activation):
        from .pages import PageCapacityError
        first.tier, first.activation = tier, activation
        active, partial, waiting = {}, {}, deque([(first, None)])
        cache=getattr(executor,'prefix_cache',None)
        if self.prefix_cache_tokens and cache is None:
            from .prefix import PrefixCache
            cache=executor.prefix_cache=PrefixCache(executor,self.prefix_cache_tokens)
        chunk_size = ((self.prefill_chunk_size or executor.context)
                      if (self.prefill_chunk_size or cache is not None) and getattr(executor,'supports_chunked_prefill',False) else 0)
        owned = set()
        prepared = []
        try:
            while waiting or active or partial:
                with self.condition:
                    while len(waiting)+len(active)+len(partial)<self.batch_size:
                        request=self._next(first.alias)
                        if request is None:
                            break
                        waiting.append((request,None))
                for request,tokens in list(waiting):
                    if request.cancelled.is_set() or time.monotonic()-request.last_progress>self.queue_timeout:
                        self._finish(request, None if request.cancelled.is_set() else BusyError('KV admission timeout'))
                        waiting.remove((request,tokens))
                prepared=[]
                while waiting and len(active)+len(partial)+len(prepared)<self.batch_size:
                    request,tokens=waiting[0]
                    slot=next(i for i in range(self.batch_size) if i not in owned)
                    try:
                        if tokens is None:
                            tokens=self._prepare(request,executor)
                            waiting[0]=(request,tokens)
                        executor.reserve_request(slot,len(tokens)+request.max_tokens)
                    except PageCapacityError:
                        break  # Preserve FIFO while existing reservations finish.
                    except Exception as error:
                        self._finish(request,error)
                        waiting.popleft()
                        continue
                    request.slot=slot
                    owned.add(slot)
                    waiting.popleft()
                    prepared.append((request,tokens))
                if chunk_size:
                    for request,tokens in prepared:
                        try:
                            reused,logits=cache.restore(tokens,request.slot) if cache is not None else (0,None)
                            request.cached_tokens=reused
                            if logits is None:
                                partial[request.slot]=(request,tokens,reused)
                            else:
                                token=request.sampler.select(logits.squeeze(0)).item()
                                if self._emit(request,token,executor,len(tokens)):
                                    executor.release_request(request.slot)
                                    owned.remove(request.slot)
                                else:
                                    active[request.slot]=(request,len(tokens))
                        except Exception as error:
                            self._finish(request,error)
                            executor.release_request(request.slot)
                            owned.remove(request.slot)
                    prepared=[]
                if prepared:
                    try:
                        logits=executor.prefill_batch([tokens for _,tokens in prepared],[r.slot for r,_ in prepared])
                        selected=sample_rows(logits,[r.sampler for r,_ in prepared])
                        for (request,tokens),token in zip(prepared,selected):
                            if self._emit(request,token,executor,len(tokens)):
                                executor.release_request(request.slot)
                                owned.remove(request.slot)
                            else:
                                active[request.slot]=(request,len(tokens))
                    except Exception as error:
                        for request,_ in prepared:
                            self._finish(request,error)
                            active.pop(request.slot,None)
                            if request.slot in owned:
                                executor.release_request(request.slot)
                                owned.remove(request.slot)
                    prepared=[]
                for slot,(request,_,__) in list(partial.items()):
                    if request.cancelled.is_set():
                        self._finish(request)
                        executor.release_request(slot)
                        owned.remove(slot)
                        del partial[slot]
                # Bound prompt work between decode steps, keeping its reservation.
                if partial:
                    slot=next(iter(partial))
                    request,tokens,start=partial[slot]
                    end=min(start+chunk_size,len(tokens))
                    try:
                        logits=executor.prefill_chunk(tokens[start:end],slot,start,final=end==len(tokens))
                        if end==len(tokens):
                            if cache is not None:
                                cache.remember(tokens,slot,logits)
                            token=request.sampler.select(logits.squeeze(0)).item()
                            if self._emit(request,token,executor,len(tokens)):
                                executor.release_request(slot)
                                owned.remove(slot)
                            else:
                                active[slot]=(request,len(tokens))
                            del partial[slot]
                        else:
                            partial[slot]=(request,tokens,end)
                    except Exception as error:
                        self._finish(request,error)
                        executor.release_request(slot)
                        owned.remove(slot)
                        del partial[slot]
                for slot,(request,_) in list(active.items()):
                    timed_out=request.events.full() and time.monotonic()-request.last_progress>self.queue_timeout
                    if request.cancelled.is_set() or timed_out:
                        self._finish(request,BusyError('stream backpressure timeout') if timed_out else None)
                        executor.release_request(slot)
                        owned.remove(slot)
                        del active[slot]
                ready=[(slot,r,length) for slot,(r,length) in active.items() if not r.events.full()]
                if ready:
                    logits,next_ids=executor.decode_batch([r.output[-1] for _,r,_ in ready],[slot for slot,_,_ in ready])
                    selected=sample_rows(logits,[r.sampler for _,r,_ in ready],next_ids)
                    for (slot,request,length),token in zip(ready,selected):
                        request.max_batch_seen=max(request.max_batch_seen,len(ready))
                        if self._emit(request,token,executor,length):
                            executor.release_request(slot)
                            owned.remove(slot)
                            del active[slot]
                with self.condition:
                    if not waiting and len(active)+len(partial)<self.batch_size:
                        request=self._next(first.alias)
                        if request is not None:
                            waiting.append((request,None))
                    if (active or waiting) and not ready and not prepared and not partial:
                        self.condition.wait(timeout=.02)
        except Exception as error:
            for request,_ in [*active.values(),*waiting,*prepared]:
                self._finish(request,error)
            for request,_,__ in partial.values():
                self._finish(request,error)
            raise
        finally:
            for slot in owned:
                executor.release_request(slot)

    def _group(self, first, executor, tier, activation):
        if self.prefix_cache_tokens and not getattr(executor, 'supports_prefix_cache', True):
            raise ValueError('this architecture does not yet support prefix snapshots')
        if getattr(executor,'requires_full_prefill',False) and (self.prefill_chunk_size or self.prefix_cache_tokens):
            raise ValueError('this architecture does not yet support prompt chunking or prefix snapshots')
        if hasattr(executor,'reserve_request'):
            return self._paged_group(first,executor,tier,activation)
        if (self.prefill_chunk_size or self.prefix_cache_tokens) and getattr(executor,'supports_chunked_prefill',False):
            return self._chunked_group(first,executor,tier,activation)
        first.tier, first.activation = tier, activation
        active = {}  # slot -> (request, prompt length)
        next_request = first
        try:
            while next_request is not None or active:
                if next_request is not None:
                    incoming = [next_request]
                    next_request = None
                    with self.condition:
                        while len(incoming) + len(active) < self.batch_size:
                            request = self._next(first.alias)
                            if request is None:
                                break
                            incoming.append(request)
                    prepared = []
                    free_slots = iter(i for i in range(self.batch_size) if i not in active)
                    for request in incoming:
                        try:
                            if request.cancelled.is_set():
                                self._finish(request)
                                continue
                            tokens = self._prepare(request,executor)
                            request.slot = next(free_slots)
                            prepared.append((request, tokens))
                        except Exception as error:
                            self._finish(request, error)
                    if prepared:
                        try:
                            logits = executor.prefill_batch(
                                [tokens for _, tokens in prepared],
                                [request.slot for request, _ in prepared])
                            first_tokens = sample_rows(logits, [r.sampler for r, _ in prepared])
                            for (request, tokens), token in zip(prepared, first_tokens):
                                if not self._emit(request, token, executor, len(tokens)):
                                    active[request.slot] = (request, len(tokens))
                        except Exception as error:
                            for request, _ in prepared:
                                self._finish(request, error)
                                active.pop(request.slot, None)
                for slot, (request, _) in list(active.items()):
                    if request.cancelled.is_set():
                        self._finish(request)
                        del active[slot]
                    elif request.events.full() and time.monotonic() - request.last_progress > self.queue_timeout:
                        self._finish(request, BusyError("stream backpressure timeout"))
                        del active[slot]
                ready = [(slot, request, length) for slot, (request, length) in active.items()
                         if not request.events.full()]
                if ready and not self._speculate(ready,active,executor):
                    logits, next_tokens = executor.decode_batch([r.output[-1] for _, r, _ in ready],
                                                           [slot for slot, _, _ in ready])
                    selected = sample_rows(logits, [r.sampler for _, r, _ in ready], next_tokens)
                    for (slot, request, length), token in zip(ready, selected):
                        request.max_batch_seen = max(request.max_batch_seen, len(ready))
                        if self._emit(request, token, executor, length):
                            del active[slot]
                with self.condition:
                    if len(active) < self.batch_size:
                        next_request = self._next(first.alias)
                    if active and not ready and next_request is None:
                        self.condition.wait(timeout=0.02)
        except Exception as error:
            for request, _ in active.values():
                self._finish(request, error)
            if next_request:
                self._finish(next_request, error)
            raise

    def _work(self):
        while True:
            with self.condition:
                first = self._next()
                while first is None and not self.closed:
                    self.condition.wait()
                    first = self._next()
                if self.closed:
                    return
            if first.command is not None:
                try:
                    if first.command['action'] == 'embed':
                        options = first.command
                        first.final = self.runtime.embed(options['model'], options['inputs'],
                                                         options['encoding_format'], options['dimensions'])
                    elif first.command['action']=='rerank':
                        options=first.command
                        first.final=self.runtime.rerank(options['model'],options['query'],options['documents'],
                            options['top_n'],options['return_documents'])
                    elif first.command['action']=='score':
                        options=first.command
                        first.final=self.runtime.score(options['model'],options['prompt'],options['candidate_token_ids'])
                    else:
                        first.final = self.runtime.manage(**first.command)
                    self._finish(first)
                except Exception as error:
                    self._finish(first, error)
                continue
            try:
                with self.runtime.session(first.alias) as (executor, tier, activation):
                    wait_for_batch(self,first,self.batch_wait_seconds)
                    self._group(first, executor, tier, activation)
            except Exception as error:
                if not first.done.is_set():
                    self._finish(first, error)
            finally:
                # A worker local otherwise retains the previous model while the
                # next session tries to evict it and reserve replacement VRAM.
                executor = None

    def close(self):
        with self.condition:
            self.closed = True
            for request in tuple(self.requests):
                request.cancelled.set()
                self._finish(request, BusyError("runtime closed"))
            self.condition.notify_all()
        self.worker.join(timeout=30)
